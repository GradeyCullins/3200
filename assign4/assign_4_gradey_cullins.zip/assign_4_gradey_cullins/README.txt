The PDF report is contained in the root directory of this folder. All matlab code is under the 'matlab' directory. Main.m is the starting point of the program, all other
functions are called from this point.
