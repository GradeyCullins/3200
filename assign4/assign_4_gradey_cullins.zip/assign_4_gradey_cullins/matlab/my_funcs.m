function F = my_funcs(x)
F = [
        x(1)^3 + x(2) - 1;
        x(2)^3 - x(1) + 1
     ];    
end