function F = hard_funcs(x)
F(1) = x(1)^2 + (x(2)^2) - 2;
F(2) = exp(x(1) - 1) - (x(2)^2) -2;
end