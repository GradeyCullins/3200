All matlab code is contained in 'main.m', please import the file into matlab to run.

The final report is also included in this folder. 

Have a nice Summer!
